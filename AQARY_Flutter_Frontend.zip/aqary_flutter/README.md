# AQARY — Flutter Frontend Scaffold

A frontend-only Flutter implementation of the AQARY app, matching the HTML
mockup and the Properties Module Architecture document. No backend is wired
up yet — `lib/data/mock_data.dart` stands in for the API described in that
document, so every screen already runs and looks right; swapping mock calls
for real HTTP calls later shouldn't require changing any screen code.

## What's implemented

- **Onboarding** — Welcome → Sign Up (Purchase or Sell) → role-specific form
  (Sell adds Agent Licence + Photo ID upload)
- **Home** — 5 live modules, 3 "coming soon" modules
- **Properties, fully wired for Residential** — Properties → Residential →
  Buy/Rent → Villa/Apartment/Land → results (List/Map toggle, filters,
  Schedule a Viewing)
- **Trust & Verification admin panel** — Pending Approvals → Review Listing
  (Approve/Reject)

Commercial, Agriculture, and Industrial are represented in the top-level
grid but not built out — see "Extending the taxonomy" below; it's a data
change, not new screen code, by design.

## Architecture notes

Two components carry almost the entire app, per the Properties Module
Architecture doc's core decision to avoid one hardcoded screen per category:

- `CategoryGridScreen` (`lib/screens/properties/category_grid_screen.dart`)
  — every category-selection screen (Properties, Residential, Buy, Rent)
- `PropertyResultsScreen` (`lib/screens/properties/property_results_screen.dart`)
  — every filtered results screen (Villas, Apartments, ...)

`lib/screens/properties/properties_flow.dart` is where these two components
get wired into the actual taxonomy tree with real data. **This is the file
to edit when adding Commercial, Agriculture, or Industrial** — copy the
Residential pattern (`buildResidentialScreen` → `buildBuyScreen` →
`_buildBuyResults`) with the corresponding lists already sitting ready in
`mock_data.dart` (`commercialPropertyTypes`, `agriculturePropertyTypes`).

## Getting started

This folder contains `lib/`, `pubspec.yaml`, and this README — it is not a
complete Flutter project on its own (no `android/`, `ios/`, or platform
folders). To run it:

```bash
# 1. Create a fresh Flutter project (generates the platform folders)
flutter create aqary_app
cd aqary_app

# 2. Replace the generated lib/ and pubspec.yaml with the ones from this scaffold
rm -rf lib
cp -r /path/to/this/scaffold/lib .
cp /path/to/this/scaffold/pubspec.yaml .

# 3. Install dependencies
flutter pub get

# 4. Run it
flutter run
```

Requires Flutter 3.10+ (Dart 3.3+). If you're on an older Flutter version
and hit issues with Material 3 widgets (`NavigationBar`), upgrade with
`flutter upgrade` first.

## What's deliberately not here yet

Per the Statement of Work's declared scope, this does not include: full
Loan application (bank integration), E-Gov, AI Assistant, a real map
(the Map view is a static placeholder — wire in `google_maps_flutter` or
Mapbox once the backend can supply coordinates), or any networking layer.
Authentication forms validate locally but don't call an API yet.
